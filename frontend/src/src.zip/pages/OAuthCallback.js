import { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';

export default function OAuthCallback() {
  const [params] = useSearchParams();
  const token = params.get('token');
  const error = params.get('error');
  const navigate = useNavigate();

  useEffect(() => {
    if (token) {
      localStorage.setItem('token', token); // ✅ 이거면 충분
      console.log('✅ JWT 저장 완료:', token);
      navigate('/');
    } else if (error) {
      alert('소셜 로그인 실패: ' + decodeURIComponent(error));
      navigate('/login');
    } else {
      alert('예상치 못한 오류가 발생했습니다.');
      navigate('/login');
    }
  }, [token, error, navigate]);

  return <p>로그인 중입니다...</p>;
}