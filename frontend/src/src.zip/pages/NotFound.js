export default function NotFound() {
  return (
    <div style={{ padding: '40px', textAlign: 'center' }}>
      <h2>404</h2>
      <p>페이지를 찾을 수 없습니다.</p>
    </div>
  );
}