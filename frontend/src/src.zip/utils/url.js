export const toAbsoluteImageUrl = (path) => {
  if (!path) return '/no-image.png';
  return path;
};