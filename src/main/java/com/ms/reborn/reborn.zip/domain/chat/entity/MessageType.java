package com.ms.reborn.domain.chat.entity;

public enum MessageType {
    TEXT, IMAGE, VIDEO
}